﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double notas = 0;
            double média = 0;
            string aux;


            double[,] matriz = new double[2, 3];


            for (int i = 0; i < matriz.GetLength(0); i++) ;
            {

                for (int j = 0; j < matriz.GetLength(1); j++)
                {
                    aux = Interaction.InputBox()





            }




            } }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
           listBox1.Items.Clear();
        }
    }
}
