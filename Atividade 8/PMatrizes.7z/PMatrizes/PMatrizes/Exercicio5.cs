﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Exercicio5 : Form
    {
        public Exercicio5()
        {
            InitializeComponent();
        }

        private void btn_verificar_Click(object sender, EventArgs e)
        {
            string[,] respostas = new string[6, 10];
            char[] gabarito = new char[10] {'A', 'B', 'C', 'D', 'E', 'A', 'B', 'C', 'D', 'E'};
            char resposta;

            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    respostas[i, j] = Interaction.InputBox($"Digite a resposta {j + 1} do aluno {i + 1}", "Entrada de dados");
                    if (char.TryParse(respostas[i, j], out resposta) && (char.ToUpper(resposta) < 70) && (char.ToUpper(resposta) > 64))
                    {
                        if (resposta == gabarito[j])
                        {
                            lstbox_Correcao.Items.Add($"O aluno {i + 1} acertou a questão: {j + 1} era {gabarito[j]} escolheu {resposta}");
                        }
                        else
                        {
                            lstbox_Correcao.Items.Add($"O aluno {i + 1} errou a questão: {j + 1} era {gabarito[j]} escolheu {resposta}");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Resposta inválida");
                        j--;
                    }
                    
                }
            }
        }
    }
}
