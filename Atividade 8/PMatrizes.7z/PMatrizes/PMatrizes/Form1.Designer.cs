﻿namespace PMatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_exercicio1 = new System.Windows.Forms.Button();
            this.btn_exercicio2 = new System.Windows.Forms.Button();
            this.btn_exercicio3 = new System.Windows.Forms.Button();
            this.btn_exercicio4 = new System.Windows.Forms.Button();
            this.btn_exercicio5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_exercicio1
            // 
            this.btn_exercicio1.Location = new System.Drawing.Point(453, 75);
            this.btn_exercicio1.Name = "btn_exercicio1";
            this.btn_exercicio1.Size = new System.Drawing.Size(200, 200);
            this.btn_exercicio1.TabIndex = 0;
            this.btn_exercicio1.Text = "Exercicio 1";
            this.btn_exercicio1.UseVisualStyleBackColor = true;
            this.btn_exercicio1.Click += new System.EventHandler(this.btn_exercicio1_Click);
            // 
            // btn_exercicio2
            // 
            this.btn_exercicio2.Location = new System.Drawing.Point(701, 75);
            this.btn_exercicio2.Name = "btn_exercicio2";
            this.btn_exercicio2.Size = new System.Drawing.Size(200, 200);
            this.btn_exercicio2.TabIndex = 1;
            this.btn_exercicio2.Text = "Exercicio 2";
            this.btn_exercicio2.UseVisualStyleBackColor = true;
            this.btn_exercicio2.Click += new System.EventHandler(this.btn_exercicio2_Click);
            // 
            // btn_exercicio3
            // 
            this.btn_exercicio3.Location = new System.Drawing.Point(453, 281);
            this.btn_exercicio3.Name = "btn_exercicio3";
            this.btn_exercicio3.Size = new System.Drawing.Size(200, 200);
            this.btn_exercicio3.TabIndex = 2;
            this.btn_exercicio3.Text = "Exercicio 3";
            this.btn_exercicio3.UseVisualStyleBackColor = true;
            this.btn_exercicio3.Click += new System.EventHandler(this.btn_exercicio3_Click);
            // 
            // btn_exercicio4
            // 
            this.btn_exercicio4.Location = new System.Drawing.Point(701, 281);
            this.btn_exercicio4.Name = "btn_exercicio4";
            this.btn_exercicio4.Size = new System.Drawing.Size(200, 200);
            this.btn_exercicio4.TabIndex = 3;
            this.btn_exercicio4.Text = "Exercicio 4";
            this.btn_exercicio4.UseVisualStyleBackColor = true;
            this.btn_exercicio4.Click += new System.EventHandler(this.btn_exercicio4_Click);
            // 
            // btn_exercicio5
            // 
            this.btn_exercicio5.Location = new System.Drawing.Point(561, 487);
            this.btn_exercicio5.Name = "btn_exercicio5";
            this.btn_exercicio5.Size = new System.Drawing.Size(200, 200);
            this.btn_exercicio5.TabIndex = 4;
            this.btn_exercicio5.Text = "Exercicio 5";
            this.btn_exercicio5.UseVisualStyleBackColor = true;
            this.btn_exercicio5.Click += new System.EventHandler(this.btn_exercicio5_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1456, 699);
            this.Controls.Add(this.btn_exercicio5);
            this.Controls.Add(this.btn_exercicio4);
            this.Controls.Add(this.btn_exercicio3);
            this.Controls.Add(this.btn_exercicio2);
            this.Controls.Add(this.btn_exercicio1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_exercicio1;
        private System.Windows.Forms.Button btn_exercicio2;
        private System.Windows.Forms.Button btn_exercicio3;
        private System.Windows.Forms.Button btn_exercicio4;
        private System.Windows.Forms.Button btn_exercicio5;
    }
}

