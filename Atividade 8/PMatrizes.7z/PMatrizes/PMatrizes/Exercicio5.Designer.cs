﻿namespace PMatrizes
{
    partial class Exercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_verificar = new System.Windows.Forms.Button();
            this.lstbox_Correcao = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_verificar
            // 
            this.btn_verificar.Location = new System.Drawing.Point(247, 140);
            this.btn_verificar.Name = "btn_verificar";
            this.btn_verificar.Size = new System.Drawing.Size(330, 173);
            this.btn_verificar.TabIndex = 0;
            this.btn_verificar.Text = "Verificar";
            this.btn_verificar.UseVisualStyleBackColor = true;
            this.btn_verificar.Click += new System.EventHandler(this.btn_verificar_Click);
            // 
            // lstbox_Correcao
            // 
            this.lstbox_Correcao.FormattingEnabled = true;
            this.lstbox_Correcao.ItemHeight = 16;
            this.lstbox_Correcao.Location = new System.Drawing.Point(735, 30);
            this.lstbox_Correcao.Name = "lstbox_Correcao";
            this.lstbox_Correcao.Size = new System.Drawing.Size(642, 644);
            this.lstbox_Correcao.TabIndex = 1;
            // 
            // Exercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1421, 730);
            this.Controls.Add(this.lstbox_Correcao);
            this.Controls.Add(this.btn_verificar);
            this.Name = "Exercicio5";
            this.Text = "Exercicio5";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_verificar;
        private System.Windows.Forms.ListBox lstbox_Correcao;
    }
}