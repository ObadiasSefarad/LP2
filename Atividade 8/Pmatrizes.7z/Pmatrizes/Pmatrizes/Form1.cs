﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;
using System.Threading;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercício1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            for (int i = 0; i < 20; i++)

            {
                auxiliar = Interaction.InputBox($"Digite o nº " + $"da posição {i + 1} do vetor:");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido");

                    i--;

                }

                else
                {
                    auxiliar += $"Vetor[{i}] = {vetor[i]}\n";
                }
                    MessageBox.Show(auxiliar);
                }
                Array.Reverse(vetor);
            auxiliar = "Vetor na ordem inversa:\n";
            for(int i = 0;i < 20; i++)
            {
                auxiliar += $"Vetor[{i}] = {vetor[i]}\n";
            }
                MessageBox.Show(auxiliar);
            }

       

        private void btnExercício2_Click_1(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList()
            { "Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio",
             "Marcelo", "Pedro", "Thais" };

            lista.Remove("Otávio");
            string auxiliar = "";

            foreach (string nome in lista) { 
                auxiliar+=nome + "\n";
            
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercício3_Click(object sender, EventArgs e)
        {
            int alunos = 3;
            int notas = 3;
            double media = 0;
            double[,] matrizNotas = new double[alunos, notas];
            string auxiliar = "";
            string saída = "";
            for (int i = 0; i < alunos; i++) 
            {
                media = 0;
                for (int j = 0; j < notas; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}: ");
                    if (!(double.TryParse(auxiliar, out matrizNotas[i, j]) || matrizNotas[i,j] < 0 || matrizNotas[i,j] > 10))
                    {
                        MessageBox.Show("Valor inválido");
                        j--; 
                    }
                    else
                    {
                        media += matrizNotas[i, j];

                    }
                     media /= notas;
                    saída += $"Aluno {i + 1} - Média: {media:F2}\n";

                }

            }
            MessageBox.Show(saída);
        }

        private void btnExercício4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form2>().Count()>0)
            {
                Application.OpenForms.OfType<Form2>().First().BringToFront();
            }
            else
            {
                Form2 obj2 = new Form2();
                obj2.Show();
            }
        }
    }
    }
