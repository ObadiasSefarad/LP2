﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;

        private void txtnumero2_Validated(object sender, EventArgs e)
        {


            try
            {
                errorProvider2.SetError(txtnumero2, "");
                numero2 = Convert.ToDouble(txtnumero2.Text);

            }
            catch {

                errorProvider2.SetError(txtnumero2, "Número 2 Inválido");
                txtnumero2.Focus();
            
            }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtresultado.Text = resultado.ToString("G");
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtresultado.Text = resultado.ToString("G");
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtresultado.Text = resultado.ToString("G");
        }

        private void btnDiv_Click(object sender, EventArgs e)


        {
            if (numero2 == 0)

            {
                MessageBox.Show("Não pode dividir por zero!!!", "erro",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtnumero2.Focus();

            }
            else
            {
                resultado = numero1 / numero2;
                txtresultado.Text = resultado.ToString("G");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtnumero1.Clear();
            txtnumero2.Clear();
            txtresultado.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?",
                          "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                                == DialogResult.Yes)
            {
                {
                    Close();
                }
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtnumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnumero1.Text, out numero1))
            {
                errorProvider1.SetError(txtnumero1, "Número 1 inválido");
            }
            else
                errorProvider1.SetError(txtnumero1, "");

        }
    }
}
