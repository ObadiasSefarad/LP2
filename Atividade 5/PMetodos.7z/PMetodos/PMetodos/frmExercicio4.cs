﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContaNumero_Click(object sender, EventArgs e)
        {
            int contaNum = 0;
            int Posicao = 0;

            while (Posicao < richTextFrase.Text.Length)
            {
                if (char.IsNumber(richTextFrase.Text[Posicao]))
                {
                    contaNum++;
                }
                    Posicao++;

            }

            MessageBox.Show($"o Texto tem {contaNum} números");
        }

        private void btncaracter_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < richTextFrase.Text.Length; i++)
            
                if (Char.IsWhiteSpace(richTextFrase.Text[i]))
                {
                    MessageBox.Show($"o 1° caracter branco está na posição{i + 1}");
                    break;
                }
        }

        private void btnContarLetras_Click(object sender, EventArgs e)
          
        {   int contarLetras = 0;
            foreach (char c in richTextFrase.Text)
            {
                if (!Char.IsLetter(c)) 
                {  contarLetras++; }
            }
            MessageBox.Show($"o Texto tem {contarLetras} letras");
        }
    }       
    } 
