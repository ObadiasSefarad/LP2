﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btn_ContaNum_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contaNum = 0;

            while (contador < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[contador]))
                    contaNum++;
                contador++;
            }

            MessageBox.Show($"O texto tem {contaNum} números");
        }

        private void btn_posbranco_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    MessageBox.Show($"A posição do 1º caracter branco é: {i + 1}");
                    break;
                }
            }
        }

        private void btn_ContaLet_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;
            foreach (char c in rchtxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contaLetra++;
                }
            }

            MessageBox.Show($"o texto tem {contaLetra} letras");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmExercicio4_Load(object sender, EventArgs e)
        {

        }

        private void rchtxtFrase_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_ContaNum_Click_1(object sender, EventArgs e)
        {
            int contador = 0;
            int contaNum = 0;

            while (contador < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[contador]))
                    contaNum++;
                contador++;
            }

            MessageBox.Show($"O texto tem {contaNum} números");
        }


        private void btn_ContaLetras_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;
            foreach (char c in rchtxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contaLetra++;
                }
            }

            MessageBox.Show($"O texto tem {contaLetra} letras");
        }

        private void btn_PosBranco_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    MessageBox.Show($"A posição do 1º caracter branco é: {i + 1}");
                    break;
                } else if(i ==  rchtxtFrase.Text.Length - 1 && !Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    MessageBox.Show("O texto não contém espaços");
                }
            }
        }
    }
}
