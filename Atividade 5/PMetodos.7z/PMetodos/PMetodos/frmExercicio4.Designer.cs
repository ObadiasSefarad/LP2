﻿namespace PMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextFrase = new System.Windows.Forms.RichTextBox();
            this.btnContaNumero = new System.Windows.Forms.Button();
            this.btncaracter = new System.Windows.Forms.Button();
            this.btnContarLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTextFrase
            // 
            this.richTextFrase.Location = new System.Drawing.Point(129, 44);
            this.richTextFrase.Name = "richTextFrase";
            this.richTextFrase.Size = new System.Drawing.Size(362, 141);
            this.richTextFrase.TabIndex = 0;
            this.richTextFrase.Text = "";
            // 
            // btnContaNumero
            // 
            this.btnContaNumero.Location = new System.Drawing.Point(106, 237);
            this.btnContaNumero.Name = "btnContaNumero";
            this.btnContaNumero.Size = new System.Drawing.Size(125, 71);
            this.btnContaNumero.TabIndex = 1;
            this.btnContaNumero.Text = "Conta Número";
            this.btnContaNumero.UseVisualStyleBackColor = true;
            this.btnContaNumero.Click += new System.EventHandler(this.btnContaNumero_Click);
            // 
            // btncaracter
            // 
            this.btncaracter.Location = new System.Drawing.Point(264, 237);
            this.btncaracter.Name = "btncaracter";
            this.btncaracter.Size = new System.Drawing.Size(125, 71);
            this.btncaracter.TabIndex = 2;
            this.btncaracter.Text = "Posição 1° Caracter Branco";
            this.btncaracter.UseVisualStyleBackColor = true;
            this.btncaracter.Click += new System.EventHandler(this.btncaracter_Click);
            // 
            // btnContarLetras
            // 
            this.btnContarLetras.Location = new System.Drawing.Point(432, 237);
            this.btnContarLetras.Name = "btnContarLetras";
            this.btnContarLetras.Size = new System.Drawing.Size(125, 71);
            this.btnContarLetras.TabIndex = 3;
            this.btnContarLetras.Text = "Contar Letras";
            this.btnContarLetras.UseVisualStyleBackColor = true;
            this.btnContarLetras.Click += new System.EventHandler(this.btnContarLetras_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnContarLetras);
            this.Controls.Add(this.btncaracter);
            this.Controls.Add(this.btnContaNumero);
            this.Controls.Add(this.richTextFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextFrase;
        private System.Windows.Forms.Button btnContaNumero;
        private System.Windows.Forms.Button btncaracter;
        private System.Windows.Forms.Button btnContarLetras;
    }
}