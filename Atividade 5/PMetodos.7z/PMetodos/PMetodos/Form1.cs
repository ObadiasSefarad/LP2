﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class Form1 : Form
    {
        //Menustrip cria os menus
        // contextmenustrip cria o menu de contexto (quando clicamos no botão direito)
        public Form1()
        {
            InitializeComponent();
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você escolheu copiar");
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você escolher colar");
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e) // É a propriedade showshortcurtkey que permite ele ser um container
        {
            if (Application.OpenForms.OfType<frmExercicio2>().Count() > 0) // Testa se o formulário 2 já foi criado na memória, se sim, traz para frente
            {
                Application.OpenForms["frmExercicio2"].BringToFront();
            }
            else
            {
                frmExercicio2 frm2 = new frmExercicio2();
                frm2.MdiParent = this; // Parent = Pai, obtém o pai dele. This é o formulário em questão, ou seja, form1
                frm2.WindowState = FormWindowState.Maximized; // Em qual estado ele vai abrir (ficará maximizado dentro do primeiro)
                frm2.Show();
            }
        }

       
        
            private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e) // É a propriedade showshortcurtkey que permite ele ser um container
        {
            if (Application.OpenForms.OfType<frmExercicio3>().Count() > 0) // Testa se o formulário 2 já foi criado na memória, se sim, traz para frente
            {
                Application.OpenForms["frmExercicio3"].BringToFront();
            }
            else
            {
                frmExercicio3 frm3 = new frmExercicio3();
                frm3.MdiParent = this; // Parent = Pai, obtém o pai dele. This é o formulário em questão, ou seja, form1
                frm3.WindowState = FormWindowState.Maximized; // Em qual estado ele vai abrir (ficará maximizado dentro do primeiro)
                frm3.Show();
            }
        }

        
        
            private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e) // É a propriedade showshortcurtkey que permite ele ser um container
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0) // Testa se o formulário 2 já foi criado na memória, se sim, traz para frente
            {
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio4 frm4 = new frmExercicio4();
                frm4.MdiParent = this; // Parent = Pai, obtém o pai dele. This é o formulário em questão, ou seja, form1
                frm4.WindowState = FormWindowState.Maximized; // Em qual estado ele vai abrir (ficará maximizado dentro do primeiro)
                frm4.Show();
            }
        }

        
            private void exercício5ToolStripMenuItem_Click(object sender, EventArgs e) // É a propriedade showshortcurtkey que permite ele ser um container
        {
            if (Application.OpenForms.OfType<frmExercicio2>().Count() > 0) // Testa se o formulário 2 já foi criado na memória, se sim, traz para frente
            {
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 frm5 = new frmExercicio5();
                frm5.MdiParent = this; // Parent = Pai, obtém o pai dele. This é o formulário em questão, ou seja, form1
                frm5.WindowState = FormWindowState.Maximized; // Em qual estado ele vai abrir (ficará maximizado dentro do primeiro)
                frm5.Show();
            }
        }

        private void exercício5ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Close();
        }
    }
    }
    
  

