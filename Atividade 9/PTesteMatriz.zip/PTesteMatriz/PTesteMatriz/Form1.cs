﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PTesteMatriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList() {
            "Ana", "André", "Débora", "Fátima", "João",
             "Janete", "Otávio", "Marcelo", "Pedro", "Thais"};

            alunos.Remove("Otávio");
            String auxiliar;
            auxiliar = "";
            foreach (string s in alunos)
                auxiliar += s + "\n";

            MessageBox.Show(auxiliar);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;
            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox(
                    "Digite o {i+1}° número",
                    "Entrada de Dados"
                    );
                if (int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
            }

            Array.Reverse(vetor);

            auxiliar = "";
            foreach (int i in vetor)
                auxiliar += i + "\n";

            MessageBox.Show(auxiliar);


        }

        private void button3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string notaStr = "";
            double media = 0;
            string Saida = $"aluno:";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    notaStr = Microsoft.VisualBasic.Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}:");

                    if (!double.TryParse(notaStr, out notas[i, j]))
                    {
                        MessageBox.Show("Digite um valor válido.");
                        j--;

                    }
                    else
                    {
                        media += notas[i, j];
                    }

                }
                media = media / 3;
                Saida += $"aluno {i + 1}: média: {media:F1}\n";
            }
            MessageBox.Show(Saida);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int N = 10;
            string[] nomes = new string[N];
            int[] comprimentos = new int[N];

            for (int i = 0; i < N; i++)
            {
                nomes[i] = Microsoft.VisualBasic.Interaction.InputBox($"Digite o nome completo do aluno {i + 1}:");
                comprimentos[i] = nomes[i].Replace(" ", "").Length;
                listBox1.Items.Add($"O nome: {nomes[i]} tem {comprimentos[i]} caracteres");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int N = 10; // Substitua por seu RA
            string[,] respostas = new string[N, 10];
            string[] gabarito = { "A", "B", "C", "D", "E", "A", "B", "C", "D", "E" };
            string respostaStr = "";
            listBox1.Items.Clear();

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    do
                    {
                        respostaStr = Microsoft.VisualBasic.Interaction.InputBox($"Digite a resposta da questão {j + 1} do aluno {i + 1} (A, B, C, D ou E):");
                    }
                    while (!"ABCDE".Contains(respostaStr));

                    respostas[i, j] = respostaStr;
                }

                int acertos = 0;
                for (int j = 0; j < 10; j++)
                {
                    if (respostas[i, j] == gabarito[j])
                    {
                        acertos++;
                    }
                }

                listBox1.Items.Add($"Aluno {i + 1}: {acertos} acertos");
            }
        }
    }
}

