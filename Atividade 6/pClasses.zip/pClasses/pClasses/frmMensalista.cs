﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pClasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void btnInstanciar_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();
            objMensalista.NomeEmpregado = txtNome.Text;
            objMensalista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntrada.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(txtSalarioMensal.Text);

            MessageBox.Show("Nome=" + objMensalista.NomeEmpregado + "\n" +
                        "Matricula=" + objMensalista.Matricula + "\n" +
                        "Tempo Trabalho:" + objMensalista.TempoTrabalho() + "\n" +
                        "Salário final=" + objMensalista.SalarioBruto().ToString("N2"));


            MessageBox.Show("Nome" + objMensalista.NomeEmpregado + "\n" + );
             public static String Empresa = "Toyota";
             public const String Filial = "Filial Sorocaba";
    }

        private void btnInstanciarPassando_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista(
            Convert.ToInt32(txtMatricula.Text),
            txtNome.Text,
            Convert.ToDateTime(txtDataEntrada.Text),
            Convert.ToDouble(txtSalarioMensal.Text));
        }
    }
}
