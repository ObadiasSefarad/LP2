﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double peso=0, altura=0, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Clear();
            mskbxAltura.Clear();
            mskbxResultado.Clear();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {

                double peso = Convert.ToDouble(mskbxPeso.Text);
                double altura = Convert.ToDouble(mskbxAltura.Text);

                if (peso <= 0 || altura <= 0)
                {
                    MessageBox.Show("Valores devem ser maior que 0");
                    mskbxAltura.Focus();
                }

                {
                    imc = peso / (altura * altura);
                    imc = Math.Round(imc, 1);
                    mskbxResultado.Text = imc.ToString();


                    if (imc < 18.5)
                        MessageBox.Show("Magreza");

                    else if (imc <= 24.9)
                        MessageBox.Show("Normal");

                    else if (imc <= 29.9)
                        MessageBox.Show("Sobrepeso");

                    else if (imc <= 39.9)
                        MessageBox.Show("Obesidade");
                    else 
                            MessageBox.Show("Obesidade Grave");

                }

            }

            catch
            {
                MessageBox.Show("Valores inválidos");
                mskbxAltura.Focus();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Validated(object sender, EventArgs e)
        {




        }
    }
}


