﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriângulo
{
    public partial class Form1 : Form
    {
        double LadoA, LadoB, LadoC;

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if (!(double.TryParse(txtValorB.Text, out LadoB)))
            {
                MessageBox.Show("Valor Inválido");
                txtValorB.Focus();
            }
        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if (!(double.TryParse(txtValorC.Text, out LadoC)))
            {
                MessageBox.Show("Valor Inválido");
                txtValorC.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if ((Math.Abs(LadoB - LadoC) < LadoA) && (LadoA < LadoB + LadoC) &&
               (Math.Abs(LadoA - LadoC) < LadoB) && (LadoB < LadoA + LadoC) &&
               (Math.Abs(LadoA - LadoB) < LadoC) && (LadoC < LadoA + LadoB))
            {
                if (LadoA == LadoB && LadoA == LadoC)
                {
                    MessageBox.Show("O triângulo é equilátero");
                }
                else if (LadoA != LadoB && (LadoA != LadoC) && LadoB != LadoC)
                {
                    MessageBox.Show("O triângulo é escaleno");
                }
                else
                {
                    MessageBox.Show("O triângulo é Isósceles");
                }

            }
            else
            {
                MessageBox.Show("Não é um triângulo");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            if (!(double.TryParse(txtValorA.Text, out LadoA)))
            {
                MessageBox.Show("Valor Inválido");
                txtValorA.Focus();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
